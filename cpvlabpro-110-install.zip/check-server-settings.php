<?php //ICB0 81:0 82:79f                                                      ?><?php //00388
// * @package     CPV Lab
// * @version     11.0
// * @release     2024-06-15
// * @copyright   (C) 2024 Uptechvision Solutions. All rights reserved.
// * @link        https://cpvlab.pro
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPw19ZJi4htN/pz7p61Xj2iSJZT34KSa6kC2TdT2+VG3QQrYo51heo5MOdnkl90Rg9UK3zjli
WSJPkNalwibCOnQi5/osg2TT6aSTDm4WQIT5lx6sfntCDhJpvWlLnTouj8WNlXNnK3lyf+MpcbhF
/0ox21hCKpITDTRwA4cAaSNFHy3/udUaMfT6/4qJo5DcA3MlqOFh0/GQRLh2RsIJCynqoLwcSx5N
+a2c7hqV2rRuchJPrm44OfmQ0rYwwGKQwqaCfX3z9GjfGtLt1f9ANMbsuXb7Q0QFLsurOgD+6j/h
E7spJVyVZSI9p85OnJdAiJ9l5m+4+dRpvxEPavfuw1JrthyJS5nKzNkhZiKoCCZlggSqo5XXVBfv
Nq2r9nvSPJWAATnrBWKzurALaML0787N89duf6XzImpkRlfHZf817sxlpeVvc9dO0woW453Owcpl
fCXk88dQ7UAeNk9lmva5ow1qKxtVuqKsYdlOSRQRcQCSySPm3hhGE76Xq6U4QjQui24GC097G5Dy
35Kn9iYF2mWeG6wZqV0uemInTziYaQfK5gqmJyHqsUz2uGv8ExAbN1pirbv0hjsy2HOxIsVGAaWj
UowuKlG5yt5ELI2+j6aaORtK+/PPRc1pbosQo//gXbSBazCQCzAaizzexZzfECmnxGzSA8r6+WHL
eECjZMPR3CgnpPvJAzIAZZy1cqJS1Fc6h03FYawgz2TOrZfLjSzrcf0pulgr4FWBsl8XoUOM3nJG
fO1Tyq7b0ODwqoVg/KfX/GsyjgJ52a/6A8bCX6pkvwxYBESsAbFp9ivP4PNpc40nXOiqrqGQtNeW
xsnNLXMDpcCnHeip3cluEuCcLulaoFVrDvFwreMyKCAmNKnsMwVDnhnD+SZm/jK9lU4UlZYF3t1x
Fni9XmRpOyFw7b/U7gPZceVTmpL/taD+HsWJYW/8dgNfy0M2bsJBLHQL881M/ojeQhQVj7IH4smg
KkBWLhnuLaa25Sc9NXq96rQBfzwRlokYfFOA0OS==
HR+cPwEtjRI9XGwxL0WWbv8ij/509bMK34O5biaHE0waVKocqrtPqwExwqYqix+SflVNvP+lbL3G
LvyvQW7SBF5ir3lfsxjjD6QWgiK8h6UbMhNf1bH2qm/4zDPfiiUb6vKWZ1hhdSvVxUVG1n3vNRGe
ZbQtB86ljfQxpXCsBxO9SSa5JpAj1ucZwTWA3g84v/VCn5mlrUs/y0mCNpk8UggafVMxj/KxKsLv
/hPLWrzg8cTuAdFehpincg5cgG8/hwGVQruWcIZ/VPOtzPYoYsSZOWcScCp4Qn0nkt5zvliDVsmZ
oAmoQ/soNgcZ7+KVwFZefF+aDVKf6svsK6VLqMyiDrQA5lT9q+VjcVfR4Wu3POZjK6DF1uiHmBFa
4FqZK/N63RzvCwLEyRBx+chkDDlZVDYGtLU/hLBwKF5twUJ10T9zzXa8Ptj3w0fNI174h4+o9XHZ
t3cVDfM7tl65JqfuPMPH2u3HC8qGAAnuA+P8whJ8kfRBnjPIYW4kxZ9DMF2uUUQB/CVJwYlQ/Ud2
eUaz8NWoF+fThRtPx+hxo5tIAOJIC3TB9Op2zHxz2CNzK0yUz8A/NCyWUyTb0PbWZoWgwj6tIE4Q
6f0Cqpdw5Q4C2Bjp3Nro1KeZcl0BpL1ZsvKtBIbrYtbY0SSgmem/QpRUn+C9UCmYKySgb1Yh+Yrx
PDvZ6hmolTl3kdyeJ4JT0XjtVCfFa8K4KM4fA5ukIgNscriOM+ZjDUdOsRslAwW5uOvJ5A4r52CC
IfPw91bduAQgMlHZsdj9ktLRZHk4mqQaaGsTlcrLEWJeRI0YDP4M/+43Qo8kzZjD4wk1nlknunL0
IOBKZj+Wuoome/7fmOZFimoO0HsCSWQI142bREHpYdWx1GjXmx8fNLXKP2yMRHssWUG6JF+YGw25
y5vPYjvgErFEy4gg/v9ObLFdjQveWEjNTirkt72OGwWCAf9eBsRTXNRPQ4FZaFu6G+S3KnpJ+sVg
x0yLweJnL32H9W53QmO4NBNv5T+B3d46xG5YcuOAe/CAPU4=